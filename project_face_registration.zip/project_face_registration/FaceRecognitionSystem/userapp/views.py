import cv2
import numpy as np
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User
from django.contrib.auth.hashers import make_password  # Import for password hashing

# Function to encode face from a frame (this can be your existing face detection method)
def encode_face(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)  # Convert to grayscale
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
    
    # If faces are detected, return the first detected face region (you can improve this later)
    for (x, y, w, h) in faces:
        face = frame[y:y+h, x:x+w]  # Crop the face from the frame
        face_resized = cv2.resize(face, (200, 200))  # Resize face to fixed size (you can modify this)
        return face_resized
    return None  # Return None if no face detected

# Function to save face encoding and user data in the database
def save_face_encoding(username, password, face_encoding):
    hashed_password = make_password(password)  # Hash the password for storage

    # Save the user data (including face encoding as bytes)
    user = User(username=username, password=hashed_password, face_encoding=face_encoding.tobytes())
    user.save()

# Registration view
def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Debugging messages to ensure the form data is received
        print(f"Received Username: {username}, Password: {password}")

        # Check if both username and password are provided
        if not username or not password:
            messages.error(request, 'Username and password are required!')
            return redirect('register')  # Redirect back if fields are missing

        # Initialize webcam to capture face
        cap = cv2.VideoCapture(0)  # Access webcam
        while True:
            ret, frame = cap.read()  # Read frame from webcam
            if not ret:
                break

            face = encode_face(frame)  # Detect face
            if face is not None:
                cv2.imshow("Face Detected - Press 'c' to Confirm", face)  # Show detected face

                key = cv2.waitKey(1)
                if key == ord('c'):  # If 'c' is pressed, confirm face capture
                    print("Face captured successfully")  # Debugging message
                    save_face_encoding(username, password, face)  # Save face encoding
                    messages.success(request, 'Registration successful!')
                    cap.release()  # Release webcam
                    cv2.destroyAllWindows()  # Close webcam window
                    return redirect('login')  # Redirect to login page after registration
            elif cv2.waitKey(1) == ord('q'):  # Press 'q' to quit
                break

        cap.release()  # Release webcam after exiting loop
        cv2.destroyAllWindows()  # Close the OpenCV window
        messages.error(request, 'No face detected, please try again.')

    return render(request, 'register.html')  # Render registration page

# Login view
def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        try:
            # Fetch the user from the database
            user = User.objects.get(username=username)

            # Check if the password is correct
            if user.check_password(password):
                # Initialize webcam for face verification
                cap = cv2.VideoCapture(0)
                while True:
                    ret, frame = cap.read()
                    if not ret:
                        break

                    # Detect face in webcam frame
                    face = encode_face(frame)
                    if face is not None:
                        cv2.imshow("Face Detected - Press 'c' to Confirm", face)

                        key = cv2.waitKey(1)
                        if key == ord('c'):  # Press 'c' to confirm face capture
                            # Compare face encoding here (this can be done using face recognition methods)
                            # For now, we assume that the face matches
                            messages.success(request, 'Login successful!')
                            cap.release()
                            cv2.destroyAllWindows()
                            return redirect('home')  # Redirect to home after successful login
                    elif cv2.waitKey(1) == ord('q'):  # Press 'q' to quit
                        break

                cap.release()
                cv2.destroyAllWindows()
            else:
                messages.error(request, 'Invalid password.')

        except User.DoesNotExist:
            messages.error(request, 'Username does not exist.')

    return render(request, 'login.html')  # Render login page
